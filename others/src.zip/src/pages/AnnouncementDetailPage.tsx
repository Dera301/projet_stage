import React from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAnnouncement } from '../contexts/AnnouncementContext';
import { useAuth } from '../contexts/AuthContext';
import { 
  UserIcon, 
  CalendarIcon, 
  MapPinIcon, 
  PhoneIcon,
  EnvelopeIcon,
  AcademicCapIcon,
  HomeIcon,
  ClockIcon
} from '@heroicons/react/24/outline';

const AnnouncementDetailPage: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { announcements } = useAnnouncement();
  const { user } = useAuth();
  const [loading, setLoading] = React.useState(false);
  const [announcement, setAnnouncement] = React.useState<any | null>(null);

  React.useEffect(() => {
    const fromContext = announcements.find(a => String(a.id) === String(id));
    if (fromContext) { setAnnouncement(fromContext); return; }

    const fetchOne = async () => {
      setLoading(true);
      try {
        const res = await fetch(`http://localhost/Projet_stage/api/announcements/get_by_id.php?id=${id}`);
        const text = await res.text();
        const data = JSON.parse(text || '{}');
        if (res.ok && data.success) setAnnouncement(data.data);
      } catch (e) {
        // ignore silently
      } finally { setLoading(false); }
    };
    fetchOne();
  }, [id, announcements]);

  const getImageUrl = (imageUrl: string | undefined) => {
    if (!imageUrl) return '';
    if (imageUrl.startsWith('http')) return imageUrl;
    if (imageUrl.startsWith('/')) return `http://localhost${imageUrl}`;
    return imageUrl;
  };

  // Fonction pour formater la date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!id) return <div className="p-6">Annonce invalide</div>;
  if (loading && !announcement) return <div className="p-6">Chargement...</div>;
  if (!announcement) return (
    <div className="p-6">
      <div className="text-gray-700 mb-4">Annonce introuvable.</div>
      <button onClick={() => navigate(-1)} className="btn-secondary">Retour</button>
    </div>
  );

  const isOwn = user && Number(announcement.author?.id) === Number(user.id);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* En-tête */}
        <div className="mb-6">
          <nav className="flex items-center space-x-2 text-sm text-gray-500 mb-4">
            <Link to="/" className="hover:text-primary-600">Accueil</Link>
            <span>›</span>
            <Link to="/announcements" className="hover:text-primary-600">Annonces</Link>
            <span>›</span>
            <span className="text-gray-900">Détails de l'annonce</span>
          </nav>
          <h1 className="text-3xl font-bold text-gray-900">Annonce de recherche</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Contenu principal */}
          <div className="lg:col-span-2">
            <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
              {/* Galerie d'images */}
              {announcement.images?.[0] && (
                <div className="relative">
                  <img 
                    src={getImageUrl(announcement.images[0])} 
                    alt="annonce" 
                    className="w-full h-80 object-cover" 
                  />
                  {announcement.images.length > 1 && (
                    <div className="absolute bottom-4 right-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm">
                      +{announcement.images.length - 1} photo(s)
                    </div>
                  )}
                </div>
              )}
              
              <div className="p-6 space-y-6">
                {/* En-tête de l'annonce */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
                      <UserIcon className="w-6 h-6 text-primary-600" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-900 text-lg">
                        {announcement.author ? `${announcement.author.firstName} ${announcement.author.lastName}` : 'Utilisateur inconnu'}
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <div className="flex items-center space-x-1">
                          <CalendarIcon className="w-4 h-4" />
                          <span>{formatDate(announcement.createdAt)}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <ClockIcon className="w-4 h-4" />
                          <span>Publiée il y a {Math.floor((new Date().getTime() - new Date(announcement.createdAt).getTime()) / (1000 * 60 * 60 * 24))} jours</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {announcement.budget && (
                    <div className="text-right">
                      <div className="text-sm text-gray-500">Budget maximum</div>
                      <div className="text-2xl font-bold text-primary-600">
                        {announcement.budget.toLocaleString()} Ar
                      </div>
                      <div className="text-xs text-gray-500">/mois</div>
                    </div>
                  )}
                </div>

                {/* Contenu de l'annonce */}
                <div className="bg-gray-50 rounded-lg p-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Description de la recherche</h2>
                  <div className="text-gray-800 whitespace-pre-wrap leading-relaxed text-lg">
                    {announcement.content}
                  </div>
                </div>

                {/* Galerie d'images supplémentaires */}
                {announcement.images?.length > 1 && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Photos supplémentaires</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {announcement.images.slice(1).map((img: string, idx: number) => (
                        <img 
                          key={idx} 
                          src={getImageUrl(img)} 
                          alt={`annonce ${idx + 2}`} 
                          className="w-full h-40 object-cover rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                          onClick={() => {
                            // Ici vous pouvez implémenter une lightbox
                            console.log('Open image:', img);
                          }}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {/* Informations supplémentaires */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Préférences de colocation */}
                  <div className="bg-primary-50 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-3 flex items-center space-x-2">
                      <HomeIcon className="w-5 h-5 text-primary-600" />
                      <span>Préférences de colocation</span>
                    </h3>
                    <div className="space-y-2">
                      {announcement.preferences?.map((pref: string, index: number) => (
                        <div key={index} className="flex items-center space-x-2 text-sm text-gray-700">
                          <div className="w-2 h-2 bg-primary-500 rounded-full"></div>
                          <span>{pref}</span>
                        </div>
                      )) || (
                        <p className="text-gray-600 text-sm">Aucune préférence spécifiée</p>
                      )}
                    </div>
                  </div>

                  {/* Informations étudiantes */}
                  <div className="bg-blue-50 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-3 flex items-center space-x-2">
                      <AcademicCapIcon className="w-5 h-5 text-blue-600" />
                      <span>Informations étudiantes</span>
                    </h3>
                    <div className="space-y-2 text-sm text-gray-700">
                      <div className="flex justify-between">
                        <span>Statut:</span>
                        <span className="font-medium">{announcement.author?.userType === 'student' ? 'Étudiant' : 'Non spécifié'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Université:</span>
                        <span className="font-medium">{announcement.university || 'Non spécifiée'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Année d'étude:</span>
                        <span className="font-medium">{announcement.studyYear || 'Non spécifiée'}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="space-y-6">
              {/* Carte de contact */}
              <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Contacter {announcement.author?.firstName}</h3>
                
                {isOwn ? (
                  <div className="text-center py-4">
                    <p className="text-gray-600 mb-4">C'est votre annonce</p>
                    <button 
                      onClick={() => navigate('/dashboard')}
                      className="btn-primary w-full"
                    >
                      Gérer mes annonces
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <p className="text-gray-600 text-sm">
                      Intéressé par cette annonce ? Contactez directement {announcement.author?.firstName} pour en savoir plus.
                    </p>
                    
                    <div className="space-y-3">
                      <Link 
                        to={`/messages?to=${announcement.author.id}`}
                        className="w-full btn-primary flex items-center justify-center space-x-2"
                      >
                        <EnvelopeIcon className="w-4 h-4" />
                        <span>Envoyer un message</span>
                      </Link>
                      
                      {announcement.author?.phone && (
                        <a 
                          href={`tel:${announcement.author.phone}`}
                          className="w-full btn-secondary flex items-center justify-center space-x-2"
                        >
                          <PhoneIcon className="w-4 h-4" />
                          <span>Appeler</span>
                        </a>
                      )}
                    </div>
                    
                    <div className="pt-4 border-t border-gray-200">
                      <div className="text-xs text-gray-500">
                        <p>💡 Conseil: Soyez précis dans votre message et présentez-vous brièvement.</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Statistiques de l'annonce */}
              <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Statistiques</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Vues:</span>
                    <span className="font-semibold">{announcement.views || 0}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Intéressés:</span>
                    <span className="font-semibold">{announcement.interestedCount || 0}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Partages:</span>
                    <span className="font-semibold">{announcement.shares || 0}</span>
                  </div>
                </div>
              </div>

              {/* Actions rapides */}
              <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Actions</h3>
                <div className="space-y-3">
                  <button className="w-full btn-secondary flex items-center justify-center space-x-2">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                    </svg>
                    <span>Sauvegarder</span>
                  </button>
                  <button className="w-full btn-secondary flex items-center justify-center space-x-2">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                    </svg>
                    <span>Partager</span>
                  </button>
                  <button className="w-full btn-secondary flex items-center justify-center space-x-2">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    <span>Signaler</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Boutons de navigation en bas */}
        <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-200">
          <button 
            onClick={() => navigate(-1)} 
            className="btn-secondary flex items-center space-x-2"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            <span>Retour</span>
          </button>
          
          <Link to="/announcements" className="btn-primary">
            Voir toutes les annonces
          </Link>
        </div>
      </div>
    </div>
  );
};

export default AnnouncementDetailPage;