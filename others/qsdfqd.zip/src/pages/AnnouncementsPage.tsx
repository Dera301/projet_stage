import React from 'react';
import { useAnnouncement } from '../contexts/AnnouncementContext';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { ChatBubbleLeftRightIcon as ChatIcon, PhotoIcon, PlusIcon } from '@heroicons/react/24/outline';
import { formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';

const AnnouncementsPage: React.FC = () => {
  const { announcements, loading } = useAnnouncement();
  const { user } = useAuth();
  const navigate = useNavigate();

  const getImageUrl = (imageUrl: string | undefined) => {
    if (!imageUrl) return '/api/placeholder/400/300';
    if (imageUrl.startsWith('http')) return imageUrl;
    if (imageUrl.startsWith('/')) return `http://localhost${imageUrl}`;
    return imageUrl;
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Annonces des étudiants</h1>
            <p className="text-gray-600">Recherches de colocation publiées par les étudiants</p>
          </div>
          {user?.userType === 'student' && (
            <Link to="/create-announcement" className="btn-primary flex items-center space-x-2">
              <PlusIcon className="w-4 h-4" />
              <span>Publier une annonce</span>
            </Link>
          )}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-24">
            <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-primary-600"></div>
          </div>
        ) : announcements.length === 0 ? (
          <div className="text-center py-24">
            <PhotoIcon className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Aucune annonce pour le moment</h3>
            <p className="text-gray-600 mb-4">Soyez le premier à publier une annonce de colocation.</p>
            {user?.userType === 'student' && (
              <Link to="/create-announcement" className="btn-primary">Publier</Link>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {announcements.map((a) => (
              <div key={a.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
                {a.images?.[0] ? (
                  <img src={getImageUrl(a.images[0])} alt="annonce" className="w-full h-40 object-cover" />
                ) : (
                  <div className="w-full h-40 bg-gray-100 flex items-center justify-center text-gray-400">
                    <PhotoIcon className="w-8 h-8" />
                  </div>
                )}
                <div className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-semibold text-gray-900 truncate">
                      {a.author.firstName} {a.author.lastName}
                    </div>
                    <div className="text-xs text-gray-500">
                      {formatDistanceToNow(new Date(a.createdAt), { addSuffix: true, locale: fr })}
                    </div>
                  </div>
                  <p className="text-sm text-gray-700 line-clamp-3 mb-3">{a.content}</p>
                  <div className="flex items-center justify-between">
                    <button
                      onClick={() => navigate(`/messages?to=${a.author.id}`)}
                      className="btn-primary flex items-center space-x-2"
                    >
                      <ChatIcon className="w-4 h-4" />
                      <span>Contacter</span>
                    </button>
                    {a.images?.length > 1 && (
                      <div className="text-xs text-gray-500">+{a.images.length - 1} autres</div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AnnouncementsPage;
