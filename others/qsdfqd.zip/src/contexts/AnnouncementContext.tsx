import React, { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';
import { useAuth } from './AuthContext';
import toast from 'react-hot-toast';

export interface Announcement {
  id: string;
  authorId: string;
  author: {
    id: string;
    firstName: string;
    lastName: string;
    userType: 'student' | 'owner';
  };
  content: string;
  images: string[];
  contact?: string;
  createdAt: string;
}

export interface CreateAnnouncementData {
  content: string;
  images: string[];
  contact?: string;
}

interface AnnouncementContextType {
  announcements: Announcement[];
  userAnnouncements: Announcement[];
  loading: boolean;
  fetchAnnouncements: () => Promise<void>;
  fetchUserAnnouncements: () => Promise<void>;
  createAnnouncement: (data: CreateAnnouncementData) => Promise<void>;
  deleteAnnouncement: (id: string) => Promise<void>;
}

const AnnouncementContext = createContext<AnnouncementContextType | undefined>(undefined);

export const useAnnouncement = () => {
  const ctx = useContext(AnnouncementContext);
  if (!ctx) throw new Error('useAnnouncement must be used within AnnouncementProvider');
  return ctx;
};

export const AnnouncementProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [userAnnouncements, setUserAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  const API_BASE_URL = 'http://localhost/Projet_stage/api/announcements';

  const handleResponse = async (response: Response) => {
    const text = await response.text();
    try {
      const data = JSON.parse(text);
      if (!response.ok) throw new Error(data.message || `Erreur ${response.status}`);
      return data.data ?? data;
    } catch (e) {
      if (text.includes('<!DOCTYPE') || text.includes('<br')) {
        throw new Error("Erreur de configuration du serveur pour les annonces");
      }
      if (response.ok && text === '') return null;
      throw new Error('Réponse invalide du serveur');
    }
  };

  const fetchAnnouncements = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE_URL}/get_all.php`);
      const data = await handleResponse(res);
      setAnnouncements(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error(err);
      toast.error('Impossible de charger les annonces');
      setAnnouncements([]);
    } finally { setLoading(false); }
  }, []);

  const fetchUserAnnouncements = useCallback(async () => {
    if (!user) { setUserAnnouncements([]); return; }
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE_URL}/get_by_user.php?userId=${user.id}`);
      const data = await handleResponse(res);
      setUserAnnouncements(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error(err);
      toast.error('Impossible de charger vos annonces');
      setUserAnnouncements([]);
    } finally { setLoading(false); }
  }, [user]);

  const createAnnouncement = async (data: CreateAnnouncementData) => {
    if (!user) throw new Error('Non connecté');
    setLoading(true);
    try {
      const payload = { ...data, authorId: user.id };
      const res = await fetch(`${API_BASE_URL}/create.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const created = await handleResponse(res);
      setAnnouncements(prev => [created, ...prev]);
      if (String(created.authorId) === String(user.id)) {
        setUserAnnouncements(prev => [created, ...prev]);
      }
      toast.success('Annonce publiée !');
    } catch (err: any) {
      toast.error(err.message || 'Erreur lors de la publication');
      throw err;
    } finally { setLoading(false); }
  };

  const deleteAnnouncement = async (id: string) => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE_URL}/delete.php?id=${id}`, { method: 'DELETE' });
      await handleResponse(res);
      setAnnouncements(prev => prev.filter(a => a.id !== id));
      setUserAnnouncements(prev => prev.filter(a => a.id !== id));
      toast.success('Annonce supprimée');
    } catch (err) {
      toast.error('Suppression impossible');
      throw err;
    } finally { setLoading(false); }
  };

  useEffect(() => { fetchAnnouncements(); }, [fetchAnnouncements]);
  useEffect(() => { fetchUserAnnouncements(); }, [fetchUserAnnouncements]);

  return (
    <AnnouncementContext.Provider value={{ announcements, userAnnouncements, loading, fetchAnnouncements, fetchUserAnnouncements, createAnnouncement, deleteAnnouncement }}>
      {children}
    </AnnouncementContext.Provider>
  );
};
