<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

$storageDir = __DIR__;
$dataFile = $storageDir . '/data.json';
if (!file_exists($dataFile)) { file_put_contents($dataFile, json_encode([])); }

$input = file_get_contents('php://input');
$body = json_decode($input, true);
if (!$body || !isset($body['authorId']) || !isset($body['content'])) {
  http_response_code(400);
  echo json_encode([ 'success' => false, 'message' => 'authorId et content sont requis' ]);
  exit;
}

$announcements = json_decode(file_get_contents($dataFile), true);
if (!is_array($announcements)) { $announcements = []; }

$id = uniqid('ann_', true);
$now = date('c');
$new = [
  'id' => $id,
  'authorId' => (string)$body['authorId'],
  'author' => isset($body['author']) ? $body['author'] : null,
  'content' => trim($body['content']),
  'images' => isset($body['images']) && is_array($body['images']) ? $body['images'] : [],
  'contact' => isset($body['contact']) ? $body['contact'] : null,
  'createdAt' => $now,
];
array_unshift($announcements, $new);
file_put_contents($dataFile, json_encode($announcements, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

echo json_encode([ 'success' => true, 'data' => $new ]);
