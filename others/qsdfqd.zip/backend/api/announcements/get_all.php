<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$storageDir = __DIR__;
$dataFile = $storageDir . '/data.json';
if (!file_exists($dataFile)) { file_put_contents($dataFile, json_encode([])); }

$announcements = json_decode(file_get_contents($dataFile), true);
if (!is_array($announcements)) { $announcements = []; }

echo json_encode([ 'success' => true, 'data' => $announcements ]);
