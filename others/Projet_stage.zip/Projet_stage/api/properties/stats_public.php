<?php
include_once '../../config/data.php';
include_once '../../config/cors.php';
include_once '../../utils/response.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
  sendError('Méthode non autorisée', 405);
}

try {
  $database = new Database();
  $db = $database->getConnection();

  $propStmt = $db->prepare("SELECT COUNT(*) AS totalProperties, SUM(CASE WHEN isAvailable = 1 THEN 1 ELSE 0 END) AS availableProperties FROM properties");
  $propStmt->execute();
  $props = $propStmt->fetch(PDO::FETCH_ASSOC);

  $userStmt = $db->prepare("SELECT COUNT(*) AS totalUsers FROM users");
  $userStmt->execute();
  $users = $userStmt->fetch(PDO::FETCH_ASSOC);

  sendResponse([
    'totalProperties' => (int)($props['totalProperties'] ?? 0),
    'availableProperties' => (int)($props['availableProperties'] ?? 0),
    'totalUsers' => (int)($users['totalUsers'] ?? 0)
  ]);
} catch (Throwable $e) {
  sendError('Erreur serveur', 500);
}
?>


