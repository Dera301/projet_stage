<?php
include_once '../../config/cors.php';
include_once '../../config/data.php';
include_once '../../utils/response.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  sendError('Méthode non autorisée', 405);
}

try {
  $database = new Database();
  $db = $database->getConnection();

  // Check if any admin exists
  $check = $db->prepare("SELECT id FROM users WHERE userType = 'admin' LIMIT 1");
  $check->execute();
  if ($check->rowCount() > 0) {
    sendResponse(['created' => false, 'message' => 'Admin déjà existant']);
  }

  // Create admin with default credentials (to be changed later)
  $email = 'admin@coloc.tana';
  $password = password_hash('Admin123!', PASSWORD_BCRYPT);
  $now = date('c');

  $stmt = $db->prepare("INSERT INTO users (email, password, firstName, lastName, userType, isVerified, createdAt) VALUES (:email, :password, 'Admin', 'Root', 'admin', 1, :createdAt)");
  $stmt->bindValue(':email', $email);
  $stmt->bindValue(':password', $password);
  $stmt->bindValue(':createdAt', $now);
  $stmt->execute();

  sendResponse(['created' => true, 'email' => $email]);
} catch (Throwable $e) {
  sendError('Erreur serveur', 500);
}
?>


