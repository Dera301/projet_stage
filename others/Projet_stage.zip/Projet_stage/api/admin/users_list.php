<?php
include_once '../../config/cors.php';
include_once '../../config/data.php';
include_once '../../utils/response.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
  sendError('Méthode non autorisée', 405);
}

try {
  $database = new Database();
  $db = $database->getConnection();

  $stmt = $db->prepare("SELECT id, email, firstName, lastName, phone, userType, isVerified, createdAt FROM users ORDER BY createdAt DESC");
  $stmt->execute();
  $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
  sendResponse($users);
} catch (Throwable $e) {
  sendError('Erreur serveur', 500);
}
?>


