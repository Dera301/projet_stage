<?php
// Inclure CORS en premier
include_once '../../config/cors.php';
include_once '../../config/data.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { 
    http_response_code(204); 
    exit; 
}

parse_str($_SERVER['QUERY_STRING'] ?? '', $query);
if (!isset($query['id'])) {
    http_response_code(400);
    echo json_encode([ 
        'success' => false, 
        'message' => 'id requis' 
    ]);
    exit;
}

$id = intval($query['id']); // Convertir en int
$raw = file_get_contents('php://input');
$body = json_decode($raw, true);

try {
    // Utiliser la classe Database comme dans create.php
    $database = new Database();
    $pdo = $database->getConnection();
    
    // Construire la requête dynamiquement
    $updates = [];
    $params = [];
    
    if (isset($body['content'])) {
        $updates[] = 'content = ?';
        $params[] = trim($body['content']);
    }
    
    if (isset($body['images']) && is_array($body['images'])) {
        $updates[] = 'images = ?';
        $params[] = json_encode($body['images']);
    }
    
    if (array_key_exists('contact', $body)) {
        $updates[] = 'contact = ?';
        $params[] = $body['contact'];
    }
    
    if (empty($updates)) {
        http_response_code(400);
        echo json_encode([ 
            'success' => false, 
            'message' => 'Aucune donnée à mettre à jour' 
        ]);
        exit;
    }
    
    $params[] = $id; // Pour le WHERE
    
    $sql = "UPDATE announcements SET " . implode(', ', $updates) . " WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    // Récupérer l'annonce mise à jour
    $selectStmt = $pdo->prepare("
        SELECT 
            a.*,
            JSON_OBJECT(
                'id', u.id,
                'firstName', u.firstName,
                'lastName', u.lastName,
                'userType', u.userType
            ) as author
        FROM announcements a
        LEFT JOIN users u ON a.authorId = u.id
        WHERE a.id = ?
    ");
    $selectStmt->execute([$id]);
    $updatedAnnouncement = $selectStmt->fetch(PDO::FETCH_ASSOC);
    
    // Convertir les données
    if ($updatedAnnouncement['images']) {
        $updatedAnnouncement['images'] = json_decode($updatedAnnouncement['images'], true);
    } else {
        $updatedAnnouncement['images'] = [];
    }
    
    if ($updatedAnnouncement['author']) {
        $updatedAnnouncement['author'] = json_decode($updatedAnnouncement['author'], true);
    }
    
    echo json_encode([ 
        'success' => true, 
        'data' => $updatedAnnouncement 
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([ 
        'success' => false, 
        'message' => 'Erreur serveur: ' . $e->getMessage() 
    ]);
}
?>