<?php
// Inclure CORS en premier
include_once '../../config/cors.php';
include_once '../../config/data.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { 
    http_response_code(204); 
    exit; 
}

if (!isset($_GET['id'])) {
    http_response_code(400);
    echo json_encode([ 
        'success' => false, 
        'message' => 'id requis' 
    ]);
    exit;
}

$id = intval($_GET['id']); // Convertir en int

try {
    // Utiliser la classe Database comme dans create.php
    $database = new Database();
    $pdo = $database->getConnection();
    
    $stmt = $pdo->prepare("DELETE FROM announcements WHERE id = ?");
    $stmt->execute([$id]);
    
    $removed = $stmt->rowCount();
    
    echo json_encode([ 
        'success' => true, 
        'data' => [ 'removed' => $removed ] 
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([ 
        'success' => false, 
        'message' => 'Erreur serveur: ' . $e->getMessage() 
    ]);
}
?>