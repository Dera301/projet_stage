import React, { createContext, useState, useContext, useEffect, ReactNode, useCallback } from 'react';
import { Property, CreatePropertyData, SearchFilters } from '../types';
import { useAuth } from './AuthContext';
import toast from 'react-hot-toast';

interface PropertyContextType {
  properties: Property[];
  userProperties: Property[];
  loading: boolean;
  createProperty: (propertyData: CreatePropertyData) => Promise<void>;
  searchProperties: (filters?: SearchFilters) => Promise<Property[]>;
  fetchProperties: () => Promise<void>;
  fetchPropertyById: (id: string) => Promise<Property | null>;
  deleteProperty: (propertyId: string) => Promise<void>;
  updateProperty: (propertyId: string, updates: Partial<Property>) => Promise<Property>;
  fetchUserProperties: () => Promise<void>;
}

const PropertyContext = createContext<PropertyContextType | undefined>(undefined);

export const useProperty = () => {
  const context = useContext(PropertyContext);
  if (context === undefined) {
    throw new Error('useProperty must be used within a PropertyProvider');
  }
  return context;
};

interface PropertyProviderProps {
  children: ReactNode;
}

export const PropertyProvider: React.FC<PropertyProviderProps> = ({ children }) => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [userProperties, setUserProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  const API_BASE_URL = 'http://localhost/Projet_stage/api/properties';

  // Fonction utilitaire pour gérer les réponses
  const handleResponse = async (response: Response) => {
    const text = await response.text();      
    try {
      const data = JSON.parse(text);
      
      if (!response.ok) {
        throw new Error(data.message || `Erreur ${response.status}`);
      }

      if (data && data.success !== undefined) {
        if (data.success) {
          return data.data;
        } else {
          throw new Error(data.message || 'Erreur inconnue');
        }
      }
      
      return data;
      
    } catch (jsonError) {
      if (text.includes('<!DOCTYPE html>') || text.includes('<br />') || text.includes('<b>')) {
        console.error('Le serveur a renvoyé une page HTML au lieu de JSON:', text.substring(0, 500));
        throw new Error('Erreur de configuration du serveur. Contactez l\'administrateur.');
      }
      
      if (response.ok && text === '') {
        return null;
      }
      
      console.error('Erreur de parsing JSON:', jsonError, 'Réponse:', text.substring(0, 500));
      throw new Error('Réponse invalide du serveur');
    }
  };

  // Récupérer toutes les propriétés
  const fetchProperties = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/get_all.php`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const data = await handleResponse(response);
      
      if (Array.isArray(data)) {
        setProperties(data);
      } else {
        console.error('Les données reçues ne sont pas un tableau:', data);
        setProperties([]);
      }
    } catch (error) {
      console.error('Erreur fetchProperties:', error);
      toast.error('Erreur lors du chargement des propriétés');
      setProperties([]);
    } finally {
      setLoading(false);
    }
  }, [API_BASE_URL]);

  // Récupérer une propriété par ID
  const fetchPropertyById = async (id: string): Promise<Property | null> => {
    try {
      const response = await fetch(`${API_BASE_URL}/get_by_id.php?id=${id}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const data = await handleResponse(response);
      
      if (data && typeof data === 'object' && !Array.isArray(data)) {
        return data;
      }
      
      console.error('Données invalides pour fetchPropertyById:', data);
      return null;
    } catch (error) {
      console.error('Erreur fetchPropertyById:', error);
      toast.error('Erreur lors du chargement de la propriété');
      return null;
    }
  };

  // Créer une nouvelle propriété
  const createProperty = async (propertyData: CreatePropertyData) => {
    setLoading(true);
    try {
      if (!user) {
        throw new Error('Vous devez être connecté pour créer une propriété');
      }

      console.log('Données envoyées à l\'API:', {
        ...propertyData,
        ownerId: user.id
      });

      const propertyWithOwner = {
        ...propertyData,
        ownerId: user.id
      };

      const response = await fetch(`${API_BASE_URL}/create.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(propertyWithOwner),
      });

      const newProperty = await handleResponse(response);
      
      setProperties(prev => [newProperty, ...prev]);
      setUserProperties(prev => [newProperty, ...prev]);
      
      toast.success('Propriété créée avec succès !');
    } catch (error) {
      console.error('Erreur createProperty:', error);
      toast.error(error instanceof Error ? error.message : 'Erreur lors de la création de la propriété');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Récupérer les propriétés de l'utilisateur (version externe)
  const fetchUserProperties = useCallback(async () => {
    if (!user) {
      setUserProperties([]);
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/get_by_user.php?userId=${user.id}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const data = await handleResponse(response);
      
      if (Array.isArray(data)) {
        setUserProperties(data);
      } else {
        console.error('Les données reçues ne sont pas un tableau:', data);
        setUserProperties([]);
      }
    } catch (error) {
      console.error('Erreur fetchUserProperties:', error);
      toast.error('Erreur lors du chargement de vos propriétés');
      setUserProperties([]);
    } finally {
      setLoading(false);
    }
  }, [user, API_BASE_URL]);

  // Modifier une propriété
  const updateProperty = async (propertyId: string, updates: Partial<Property>): Promise<Property> => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/update.php?id=${propertyId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updates),
      });
      
      const updatedProperty = await handleResponse(response);
      
      setProperties(prev => prev.map(p => p.id === propertyId ? updatedProperty : p));
      setUserProperties(prev => prev.map(p => p.id === propertyId ? updatedProperty : p));
      
      toast.success('Propriété modifiée avec succès');
      return updatedProperty;
    } catch (error: any) {
      toast.error('Erreur lors de la modification de la propriété');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Supprimer une propriété
  const deleteProperty = async (propertyId: string): Promise<void> => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/delete.php?id=${propertyId}`, {
        method: 'DELETE',
      });
      
      await handleResponse(response);
      
      setProperties(prev => prev.filter(p => p.id !== propertyId));
      setUserProperties(prev => prev.filter(p => p.id !== propertyId));
      
      toast.success('Propriété supprimée avec succès');
    } catch (error: any) {
      toast.error('Erreur lors de la suppression de la propriété');
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // Rechercher des propriétés avec filtres
  const searchProperties = async (filters: SearchFilters = {}): Promise<Property[]> => {
    setLoading(true);
    try {
      const queryParams = new URLSearchParams();
      
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== '') {
          if (Array.isArray(value)) {
            value.forEach(v => queryParams.append(key, v));
          } else {
            queryParams.append(key, value.toString());
          }
        }
      });

      const url = `${API_BASE_URL}/search.php?${queryParams.toString()}`;
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const results = await handleResponse(response);
      return Array.isArray(results) ? results : [];
    } catch (error) {
      console.error('Erreur searchProperties:', error);
      toast.error('Erreur lors de la recherche des propriétés');
      return [];
    } finally {
      setLoading(false);
    }
  };

  // Effet pour charger toutes les propriétés
  useEffect(() => {
    fetchProperties();
  }, [fetchProperties]);

  // Effet pour charger les propriétés de l'utilisateur - CORRIGÉ
  useEffect(() => {
    const loadUserProperties = async () => {
      if (!user) {
        setUserProperties([]);
        return;
      }

      setLoading(true);
      try {
        const response = await fetch(`${API_BASE_URL}/get_by_user.php?userId=${user.id}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
        });

        const data = await handleResponse(response);
        
        if (Array.isArray(data)) {
          setUserProperties(data);
        } else {
          console.error('Les données reçues ne sont pas un tableau:', data);
          setUserProperties([]);
        }
      } catch (error) {
        console.error('Erreur lors du chargement des propriétés utilisateur:', error);
        toast.error('Erreur lors du chargement de vos propriétés');
        setUserProperties([]);
      } finally {
        setLoading(false);
      }
    };

    loadUserProperties();
  }, [user]); // Seulement user en dépendance

  const value: PropertyContextType = {
    properties,
    userProperties,
    loading,
    createProperty,
    searchProperties,
    fetchProperties,
    fetchPropertyById,
    deleteProperty,
    updateProperty,
    fetchUserProperties,
  };

  return (
    <PropertyContext.Provider value={value}>
      {children}
    </PropertyContext.Provider>
  );
};