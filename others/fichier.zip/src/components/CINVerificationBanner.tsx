// CINVerificationBanner.tsx - Version corrigée
import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { IdentificationIcon, XMarkIcon, ClockIcon } from '@heroicons/react/24/outline';

const CINVerificationBanner: React.FC = () => {
  const { user } = useAuth();
  const [isVisible, setIsVisible] = React.useState(true);

  // Fonction pour déterminer si l'utilisateur est vérifié
  const isUserVerified = React.useMemo(() => {
    if (!user) return false;
    
    // Vérifier les deux formats possibles (camelCase et snake_case)
    const isVerified = user.isVerified || user.is_verified;
    const cinVerified = user.cinVerified || user.cin_verified;
    
    return isVerified && cinVerified;
  }, [user]);

  // Fonction pour déterminer si la vérification est en attente
  const isVerificationPending = React.useMemo(() => {
    if (!user) return false;
    
    // Si l'utilisateur a une date de demande mais pas de date de vérification
    const hasRequested = user.cin_verification_requested_at;
    const notVerified = !(user.cinVerified || user.cin_verified);
    
    return hasRequested && notVerified;
  }, [user]);

  // Fonction pour obtenir la date d'activation
  const getActivationDeadline = React.useMemo(() => {
    if (!user) return null;
    
    // Gérer les deux formats
    if (user.accountActivationDeadline) {
      return new Date(user.accountActivationDeadline);
    }
    if (user.account_activation_deadline) {
      return new Date(user.account_activation_deadline);
    }
    return null;
  }, [user]);

  // Masquer si l'utilisateur n'est pas connecté, est admin, ou est déjà vérifié
  if (!user || user.userType === 'admin' || isUserVerified || !isVisible) {
    return null;
  }

  const activationDeadline = getActivationDeadline;
  const isWithinGracePeriod = activationDeadline ? new Date() < activationDeadline : false;

  // Si la vérification est en attente
  if (isVerificationPending) {
    return (
      <div className="bg-blue-50 border-l-4 border-blue-400 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <ClockIcon className="h-5 w-5 text-blue-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-blue-700">
                <strong>Vérification en cours :</strong> Votre demande de vérification CIN est en attente de validation par un administrateur.
                {' '}
                <Link
                  to="/profile"
                  className="font-medium underline text-blue-700 hover:text-blue-600"
                >
                  Voir mon profil →
                </Link>
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsVisible(false)}
            className="ml-auto pl-3"
          >
            <XMarkIcon className="h-5 w-5 text-blue-400 hover:text-blue-600" />
          </button>
        </div>
      </div>
    );
  }

  // Si le délai de grâce est dépassé et pas encore vérifié
  if (!isWithinGracePeriod) {
    return (
      <div className="bg-red-50 border-l-4 border-red-400 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <IdentificationIcon className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">
                <strong>Vérification requise :</strong> Votre période d'accès de 24h est terminée. Vous devez vérifier votre CIN pour continuer.
                {' '}
                <Link
                  to="/cin-verification"
                  className="font-medium underline text-red-700 hover:text-red-600"
                >
                  Vérifier maintenant →
                </Link>
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsVisible(false)}
            className="ml-auto pl-3"
          >
            <XMarkIcon className="h-5 w-5 text-red-400 hover:text-red-600" />
          </button>
        </div>
      </div>
    );
  }

  // Pendant la période de grâce (24h) - pas encore soumis de CIN
  return (
    <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            <IdentificationIcon className="h-5 w-5 text-yellow-400" />
          </div>
          <div className="ml-3">
            <p className="text-sm text-yellow-700">
              <strong>Vérification requise :</strong> Pour publier des annonces, vous devez vérifier votre carte d'identité nationale.
              {' '}
              <Link
                to="/cin-verification"
                className="font-medium underline text-yellow-700 hover:text-yellow-600"
              >
                Vérifier maintenant →
              </Link>
            </p>
          </div>
        </div>
        <button
          onClick={() => setIsVisible(false)}
          className="ml-auto pl-3"
        >
          <XMarkIcon className="h-5 w-5 text-yellow-400 hover:text-yellow-600" />
        </button>
      </div>
    </div>
  );
};

export default CINVerificationBanner;